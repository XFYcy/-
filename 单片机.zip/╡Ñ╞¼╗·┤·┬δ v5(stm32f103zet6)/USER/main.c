#include "stm32f1xx_hal.h"
#include "USART.h"
#include "OLED.h"
#include "string.h"
#include "stdio.h"
#include "Interrupt.h"
#include "HCRC04_1.h"
#include "SysTick_Delay.h"
#include "DuoJi360.h"


void SystemClock_Config(void);

char QiTa[3]={"K\x03E"};
char KeHui[3]={"K\x00E"};



volatile  char TPS[6] = "TPS\r\n"; 		//����ָ��
volatile char TPYL[7] = "TPYL\r\n"; 	//��ʼʶ��ָ��
volatile char TPYOK[8] = "TPYOK\r\n";	//�������
uint8_t start_discern_flg = 0; 			//��ʼʶ���־λ



volatile char SR1[] = "SR1=XX\r\n";	//���ؾ���
volatile char SR2[] = "SR1=ZZ\r\n";	//ȡ������


extern float Distance_1;	//���ڼ���Ƿ�������Ͷ��
extern float Distance_2;	//���ڼ���Ƿ�����
extern float Distance_3;	//���ڼ���Ƿ�����
extern float Distance_4;	//�������Ƿ�����


uint8_t	Recyclable_flg = 0;	//�ɻ���������־λ
uint8_t Harmful_flg = 0;	//�к�������־λ
uint8_t Kitchen_flg = 0;	//����������־λ
uint8_t Other_flg = 0;		//����������־λ



float distance_set_rukou = 6.0;		//����Ͷ�ſڵ���ֵ
uint8_t distance_rukou_flg = 0;		//�������Ͷ�ű�־λ


float distance_set_maizai = 15.0;   //�������ص���ֵ
uint8_t distance_maizai_flg = 0;	//���ر�־λ

uint8_t laji_down_flg = 0;			//����Ͷ�±�־λ



int main()
{
	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();
	/* Configure the system clock */
	SystemClock_Config();
	/* USER CODE BEGIN */

	DuoJi_Init();
	
	SetAngleDuoJi_1(50);
	SetAngleDuoJi_2(80);
	HAL_Delay(500);

	
	OLED_Init();
	MX_USART_UART_Init();
	HCRC04_Init();
	TIMX_Init();
	
	
	OLED_ShowString(0,10,"Dis1:",OLED_6X8);
	OLED_ShowString(0,25,"Dis2:",OLED_6X8);
	OLED_ShowString(0,40,"Dis3:",OLED_6X8);
	OLED_ShowString(0,55,"Dis4:",OLED_6X8);
	OLED_Update();
	
	

	
	while(1)
	{
		ParseData();
		HCRC04_Distance();
		
		OLED_ShowFloatNum(40,10,Distance_1,2,2,OLED_6X8);
		OLED_ShowFloatNum(40,25,Distance_2,2,2,OLED_6X8);
		OLED_ShowFloatNum(40,40,Distance_3,2,2,OLED_6X8);
		OLED_ShowFloatNum(40,55,Distance_4,2,2,OLED_6X8);
		OLED_Update();

		
		//�ж����ص����
		//����
		if(laji_down_flg == 1)
		{
			if(Distance_2 <= distance_set_maizai || Distance_3 <= distance_set_maizai || Distance_4 <= distance_set_maizai)
			{
				distance_maizai_flg = 1;
				
				HAL_UART_Transmit(&Huart, (uint8_t*)SR1, strlen(SR1), 100);
			}

		}

		//û������
		if(distance_maizai_flg == 1)
		{
			if(Distance_2 > distance_set_maizai &&  Distance_3 > distance_set_maizai && Distance_4 > distance_set_maizai) 
			{
				distance_maizai_flg = 0;
				laji_down_flg = 0;
				HAL_UART_Transmit(&Huart, (uint8_t*)SR2, strlen(SR2), 100);
			}
		
		}
	
		
		//�ж��Ƿ�������Ͷ��
		if(Distance_1 < distance_set_rukou && distance_rukou_flg == 0)
		{
			distance_rukou_flg = 1;			
		}

		
		
		
		//��ʼʶ��
		if(start_discern_flg == 1)
		{
			
			if(Recyclable_flg == 1)		//�ɻ������� 1��
			{
				SetAngleDuoJi_2(130);	
				Delay_ms(500);
				SetAngleDuoJi_1(0);
				Delay_ms(1000);
				SetAngleDuoJi_1(50);
				Delay_ms(500);
				SetAngleDuoJi_2(80);
				Delay_ms(500);
				
				Recyclable_flg = 0;
				start_discern_flg = 0;
			
				
				
			}
			else if(Kitchen_flg == 1)	//��������	2��
			{
				SetAngleDuoJi_2(30);	
				Delay_ms(500);
				SetAngleDuoJi_1(90);
				Delay_ms(1000);
				SetAngleDuoJi_1(50);
				Delay_ms(500);
				SetAngleDuoJi_2(80);
				Delay_ms(500);
				
				
				Kitchen_flg = 0;
				start_discern_flg = 0;
			}
			else if(Other_flg == 1)		//��������	3��
			{
				
				SetAngleDuoJi_2(110);	
				Delay_ms(500);
				SetAngleDuoJi_1(110);
				Delay_ms(1000);
				SetAngleDuoJi_1(50);
				Delay_ms(500);
				SetAngleDuoJi_2(80);
				Delay_ms(500);
				
				
				Other_flg = 0;
				start_discern_flg = 0;
				
			}
			else if(Harmful_flg == 1)		//�к�����	4��
			{
				
				SetAngleDuoJi_2(45);	
				Delay_ms(500);
				SetAngleDuoJi_1(0);
				Delay_ms(1000);
				SetAngleDuoJi_1(50);
				Delay_ms(500);
				SetAngleDuoJi_2(80);
				Delay_ms(500);
				
				
				Harmful_flg = 0;
				start_discern_flg = 0;
				

			}
			
			
		}
	}	
	
	
}





/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
 
  HAL_RCC_OscConfig(&RCC_OscInitStruct);
  
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}
