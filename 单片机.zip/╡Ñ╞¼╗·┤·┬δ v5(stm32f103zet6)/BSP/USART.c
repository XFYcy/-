#include "stm32f1xx_hal.h"
#include "USART.h"
#include <stdio.h>
#include "OLED.h"
/******
 ******	阻塞发送，中断接收
 ******
 ******/


uint8_t Uart_ReceiveByte [32];    /* 中断接收数据缓冲区 */



extern uint8_t Recyclable_flg;	//可回收垃圾标志位
extern uint8_t Harmful_flg;		//有害垃圾标志位
extern uint8_t Kitchen_flg;		//厨余垃圾标志位
extern uint8_t Other_flg;		//其他垃圾标志位


// 定义接收缓冲区和索引

#define RX_BUF_SIZE 256

volatile uint8_t rx_buffer[RX_BUF_SIZE];
volatile uint16_t rx_index = 0;//rx位置指针
volatile uint8_t rx_flag = 0; // 数据接收完成标志



//声明一个UART的句柄
UART_HandleTypeDef Huart;



void MX_USART_UART_Init(void)
{
	Huart.Instance = UART4;  //外设基地址
	Huart.Init.BaudRate = 9600;
	Huart.Init.HwFlowCtl = UART_HWCONTROL_NONE;  //硬件流控
	Huart.Init.Mode = UART_MODE_TX_RX;
	Huart.Init.OverSampling = UART_OVERSAMPLING_16;  //过采样（f100系列才有）
	Huart.Init.Parity = UART_PARITY_NONE; //校验位
	Huart.Init.StopBits = UART_STOPBITS_1;
	Huart.Init.WordLength = UART_WORDLENGTH_8B;	
	
	HAL_UART_Init(&Huart);
	
	//改函数会调用中断使能函数(__HAL_UART_ENABLE_IT)
//	HAL_UART_Receive_IT(&Huart,Uart_ReceiveByte,RX_Size);
	
	//当接收数据寄存器中有数据时，会触发中断。
	//__HAL_UART_ENABLE_IT(&Huart,UART_IT_RXNE);

	__HAL_UART_ENABLE_IT(&Huart,UART_IT_RXNE);	
} 
	


// MspInit()函数不需要添加到 .h 文件中
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
	 GPIO_InitTypeDef  GPIO_InitStructure;
	
	 if(huart->Instance == UART4)   // 通过基地址判断是否是USART1
	 {
		 __HAL_RCC_UART4_CLK_ENABLE();
		 __HAL_RCC_GPIOC_CLK_ENABLE();

		  //USRT1 TX 引脚初始化
		 GPIO_InitStructure.Mode = GPIO_MODE_AF_PP;
		 GPIO_InitStructure.Pin = GPIO_PIN_10;
		 GPIO_InitStructure.Pull = GPIO_PULLUP;
		 GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
		 HAL_GPIO_Init(GPIOC,&GPIO_InitStructure);
		 //USRT1 RX 引脚初始化
		 GPIO_InitStructure.Mode = GPIO_MODE_AF_INPUT;
		 GPIO_InitStructure.Pin = GPIO_PIN_11;
		 GPIO_InitStructure.Pull = GPIO_NOPULL;
		 GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
		 HAL_GPIO_Init(GPIOC,&GPIO_InitStructure);
		 
		 
		 //中断配置
		 HAL_NVIC_SetPriority(UART4_IRQn,0,0);
		 HAL_NVIC_EnableIRQ(UART4_IRQn);  
	 }
}


/***
  ** @brief  以阻塞的方式发送一定量的数据
  ** @param 指向数据缓冲区(u8或u16数据元素)的指针(地址)
  ** @param Size发送数据元素的数量(u8或u16)
  **/
void Serial_SendByte(uint8_t * TX_byte,uint16_t Size)
{
	HAL_UART_Transmit(&Huart,TX_byte ,Size,200);
}



int fputc(int ch, FILE *f)
{
	/* 发送一个字节数据到串口DEBUG_USART */
	HAL_UART_Transmit(&Huart, (uint8_t *)&ch, 1, 1000);	
	
	return (ch);
}





/***
  **	非空闲中断接收数据
  **/
void UART4_IRQHandler(void) {
	
    if (__HAL_UART_GET_FLAG(&Huart, UART_FLAG_RXNE)) {
        __HAL_UART_CLEAR_FLAG(&Huart, UART_FLAG_RXNE);
        uint8_t ch = Huart.Instance->DR;

        if (ch == 'K') {
            rx_index = 0;
            rx_buffer[rx_index++] = ch; // 存入 'K'
        } else if (rx_index > 0) { 
            if (ch == 'E') {
                rx_buffer[rx_index++] = ch; // 存入 'E'
                rx_flag = 1;               // 标记帧完成
            } else if (rx_index < RX_BUF_SIZE) {
                rx_buffer[rx_index++] = ch; // 存入数据（包括非ASCII字符）
            }
        }
    }
}






uint8_t ParseData()
{

	if(rx_flag == 1 && rx_buffer[0] == 'K' && rx_buffer[2] == 'E')
	{		
		uint8_t result = rx_buffer[1];
		
		if(result == 0x00)			// 可回收垃圾
		{
			Recyclable_flg = 1;
			OLED_ShowString(0,0,"0x00",OLED_6X8);
		}
		else if(result == 0x01)		//厨余垃圾
		{
			Kitchen_flg = 1;
			OLED_ShowString(0,0,"0x01",OLED_6X8);
		}
		else if(result == 0x02)			//有害垃圾
		{
			Harmful_flg = 1;
			OLED_ShowString(0,0,"0x02",OLED_6X8);
		}
		else if(result == 0x03)			//其他垃圾
		{
			Other_flg = 1;
			OLED_ShowString(0,0,"0x03",OLED_6X8);
		}

		OLED_Update();
		rx_flag = 0; // 清空标志
		return result;
	}
		

	
	
}





///***
//  **	接收完成回调函数
//  **/
//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//{
//	 if(huart->Instance == USART1)   // 通过基地址判断是否是USART1
//	 {
//		
//		 if(Receive_judg > 30)
//		 {
//			Receive_judg = 0;
//		 }
//		 
//		Uart_ReceiveByte[Receive_judg ++ ] = ReceiveData;
//		HAL_UART_Receive_IT(&Huart,&ReceiveData,1);
//		 

//		 
//	 }
//}










