#ifndef __UART_h
#define __UART_h

#include "stm32f1xx_hal.h"

#define RX_Size  1       /* 接收中断时每次接收的数据个数 */

extern UART_HandleTypeDef Huart;


extern uint8_t Uart_ReceiveByte[];   /* 中断接收数据缓冲区 */
extern uint8_t Uart_ReceiveFlag ;   /* 数据接收中断标志位 */

extern uint8_t Receive_judg;

void MX_USART_UART_Init(void);
void Serial_SendByte(uint8_t * TX_byte,uint16_t Size);


uint8_t ParseData();




#endif
