#ifndef __DuoJi360_h
#define __DuoJi360_h
#include "stm32f1xx_hal.h"
/****************  舵机180度 定时器初始化 ***************/
#define DuoJi_RCC_TIM_CLK_ENABLE()         __HAL_RCC_TIM1_CLK_ENABLE()
#define DuoJi_TIM 					  	   TIM1
#define DuoJi_1_TIM_Channel 			   TIM_CHANNEL_1
#define DuoJi_2_TIM_Channel 			   TIM_CHANNEL_2

/****************  舵机180度 引脚初始化 ***************/
#define DuoJi_RCC_GPIO_CLK_ENABLE()	 	  __HAL_RCC_GPIOA_CLK_ENABLE()
#define DuoJi_GPIO					  	  GPIOA
#define DuoJi_1_GPIO_PIN 				  GPIO_PIN_8
#define DuoJi_2_GPIO_PIN 				  GPIO_PIN_9

void DuoJi_Init(void);
void SetAngleDuoJi_1(uint8_t angle);
void SetAngleDuoJi_2(uint8_t angle);

#endif
