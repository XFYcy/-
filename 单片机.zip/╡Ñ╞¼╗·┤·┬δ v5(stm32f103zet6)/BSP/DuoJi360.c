#include "stm32f1xx_hal.h"
#include "DuoJi360.h"

/***
****	该舵机用定时器TIM3的通道4控制引脚为GPIOB_PIN1
****/

TIM_HandleTypeDef  tim_handle;
TIM_OC_InitTypeDef tim_handle_PWM;



void DuoJi_Init(void)
{
	
	tim_handle.Instance = DuoJi_TIM;
	tim_handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE; 
	tim_handle.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;		
	tim_handle.Init.CounterMode = TIM_COUNTERMODE_UP;
	tim_handle.Init.Period = 20000-1 ;
	tim_handle.Init.Prescaler = 72-1 ; 
		
	
	HAL_TIM_PWM_Init(&tim_handle);
	
//	tim_handle_PWM.OCFastMode = TIM_OCFAST_ENABLE;
	tim_handle_PWM.OCFastMode = TIM_OCFAST_DISABLE;
	tim_handle_PWM.OCIdleState = TIM_OCIDLESTATE_RESET;
	tim_handle_PWM.OCMode = TIM_OCMODE_PWM1;
	tim_handle_PWM.OCPolarity = TIM_OCPOLARITY_HIGH;
	tim_handle_PWM.Pulse = 1000; // 初始脉冲宽度为 1ms    			
	
	HAL_TIM_PWM_ConfigChannel(&tim_handle, &tim_handle_PWM, DuoJi_1_TIM_Channel);
	HAL_TIM_PWM_Start(&tim_handle, DuoJi_1_TIM_Channel);

	HAL_TIM_PWM_ConfigChannel(&tim_handle, &tim_handle_PWM, DuoJi_2_TIM_Channel);
	HAL_TIM_PWM_Start(&tim_handle, DuoJi_2_TIM_Channel);
//
	__HAL_TIM_MOE_ENABLE(&tim_handle);  // 关键！使能TIM1主输出
}


void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
	GPIO_InitTypeDef GPIO_InitSturcture;
	
	if(htim->Instance == DuoJi_TIM)
	{
		DuoJi_RCC_TIM_CLK_ENABLE();
		DuoJi_RCC_GPIO_CLK_ENABLE();
		
	
		GPIO_InitSturcture.Mode = GPIO_MODE_AF_PP;
		GPIO_InitSturcture.Pin  = DuoJi_1_GPIO_PIN | DuoJi_2_GPIO_PIN;
		GPIO_InitSturcture.Pull = GPIO_NOPULL;
		GPIO_InitSturcture.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(DuoJi_GPIO,&GPIO_InitSturcture);
	}
}

// 设置舵机角度（0° 到 180°）
void SetAngleDuoJi_1(uint8_t angle)
{
    uint16_t pulse_width = 1000 + (angle * 11);  
	
    __HAL_TIM_SET_COMPARE(&tim_handle, DuoJi_1_TIM_Channel, pulse_width);  
}
void SetAngleDuoJi_2(uint8_t angle)
{
    uint16_t pulse_width = 1000 + (angle * 11);  
	
    __HAL_TIM_SET_COMPARE(&tim_handle, DuoJi_2_TIM_Channel, pulse_width);  
}
