#ifndef __SysTick_Delay_h
#define __SysTick_Delay_h
#include "stm32f4xx_hal.h"

void Delay_Init(void);
void Delay_us(uint32_t us);
void Delay_ms(uint32_t us);

#endif
