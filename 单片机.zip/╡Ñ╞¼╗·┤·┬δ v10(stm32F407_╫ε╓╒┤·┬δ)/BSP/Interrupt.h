#ifndef __Interrupt_h
#define __Interrupt_h


void TIMX_Init(void);

#endif
