import os
import re
import sys
import threading
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtMultimedia import QMediaContent, QMediaPlayer
from PyQt5.QtMultimediaWidgets import QVideoWidget
from PyQt5.QtGui import *
import cv2
from yololite import *
import onnxruntime as ort
import numpy as np
from PyQt5.Qt import QUrl
from picamera2 import Picamera2
# from playsound import playsound
import serial


if os.environ.get("OS") == "Windows_NT":
    isRaspberryPi = False
else:
    isRaspberryPi = True

if isRaspberryPi:
    import RPi.GPIO as GPIO
    import serial


recyclables = 0
kitchenGarbage = 1
harmfulGarbage = 2
others = 3

# 文件夹路径,要自己修改你的路径
folder_path = os.path.abspath("/home/yufeng/laji/Photos")


# 找到最大的数
def fin_max_num():
    max_num = 0
    # 获取文件夹中的所有文件名,记得要更新文件名字
    files = os.listdir(folder_path)
    for file_name in files:
        if file_name.endswith(".png"):
            num = int(file_name.split("_")[1].split(".")[0])
            if num > max_num:
                max_num = num
    return max_num


pre_cnt = fin_max_num()  # 获取当前的图片数量
new_num = int(pre_cnt) + 1
print(f"获取到现有{pre_cnt}张图片")


class Main(QMainWindow):  # 继承QMainWindow类,继承就是把QMainWindow类的所有方法和变量继承过来。
    class imageContentResult:
        def __init__(self):
            self.id = -1
            self.postion = [-1, -1]
            self.score = 0

    class dustbin:
        def __init__(self):
            self.distance = 30




    def __init__(self):  # 创建子类__init__方法
        
        self.current_warning_type = "00"  # 初始值可设为默认类型
        self.warning_mode = False  # 警告状态标志
        # 初始化添加状态变量
        self.timer_flag = 0  # 新增控制flag (0-禁用 1-启用)
        # 其他已有初始化代码...
        super().__init__()
        # 定时器
        self.timer = QTimer()
        self.timer2 = QTimer()
        self.timer_common = QTimer()
        # 摄像头
        self.cap_video = 0
        # 记录定时器工作状态
        self.flag = 0  # 0:关闭识别
        self.busy = 0
        # self.video_stream = cv2.VideoCapture(self.cap_video)
        # self.video_stream.set(3, 640)
        # self.video_stream.set(4, 480)
        # self.video_stream.set(cv2.CAP_PROP_BRIGHTNESS, -20)  # 亮度0-100
        
        self.picam2 = Picamera2()  # 初始化Picamera2对象
        config = self.picam2.create_preview_configuration(
            main={"size": (320, 240), "format": "RGB888"},
            controls={
                "FrameRate": 30  # 帧率
            }
        )
        self.picam2.configure(config)
        self.picam2.start()  # 启动摄
        self.ui()
        self.loadModel()
        if isRaspberryPi:
            self.gpioInit()
            self.serialInit()
            uartReceiveThread = threading.Thread(target=self.uartReceiveThread)
            uartReceiveThread.start()
            # self.timeoutThread = threading.Thread(target=self.timeout)
            # self.timeoutThread.start()
        self.timer.start(10)
        self.timer2.start(200)
        self.timer_common.start(10)
        self.timer.timeout.connect(self.showImage)
        self.timer2.timeout.connect(self.stateRefresh)
        self.timer_common.timeout.connect(self.timer_commonout)
        self.personFlag = 1
        self.personDistence = [500]
        self.garbage_distance = [999,999,999,999]
        self.takePhotoFlag = 0
        self.check_have_garbage_flag = 0
        self.check_have_garbage_flag_ok = 1
        self.isshibie = 0
        self.topic1_kind = 0xFF
        self.topic1_id = 9
        self.kitchenGarbage = self.dustbin()
        self.recyclables = self.dustbin()
        self.otherGarbage = self.dustbin()
        self.harmfulGarbage = self.dustbin()
        self.number = 0
        self.kind = 3  # 其它垃圾
        self.kind_number = [0, 0, 0, 0]
        self.photo_kind_number = 0
        self.numberShow.setText("序号  垃圾种类  累计数量\r\n"+
                                " 1    有害垃圾    {:d}\r\n".format(self.kind_number[2]) +
                                " 2    可回收垃圾  {:d}\r\n".format(self.kind_number[0]) +
                                " 3    厨余垃圾    {:d}\r\n".format(self.kind_number[1]) +
                                " 4    其它垃圾    {:d}\r\n".format(self.kind_number[3])
                                )

        self.timer_common_flag = 0
        self.timer_common_flag_temp = 0
        self.pictextShow = ""
        self.kindText = ""

        # 标签字典
        self.dic_labels = {
            0: "ping",
            1: "bei",
            2: "yao",
            3: "dianchi",
            4: "shitou",
            5: "zhuankuai",
            6: "cipian",
            7: "huluobo",
            8: "bailuobo",
            9: "tudou",
        }
        self.dic_labels_cn = {
            0: "瓶子",
            1: "杯子",
            2: "药品",
            3: "电池",
            4: "石头",
            5: "砖块",
            6: "瓷片",
            7: "胡萝卜",
            8: "白萝卜",
            9: "土豆",
        }

        self.garbagekindlist = [
            [0, 1],  # recyclables 可回收垃圾
            [7, 8, 9],  # kitchenGarbage 厨余垃圾
            [2, 3],  # harmfulGarbage 有害垃圾
            [4, 5, 6],  # others 其它垃圾
        ]

        self.garbagekind = ["可回收垃圾", "厨余垃圾", "有害垃圾", "其它垃圾"]




    def ui(self):
        fontDb = QFontDatabase()
        fontID = fontDb.addApplicationFont("simkai.ttf")  # 此处的路径为qrc文件中的字体路径
        fontFamilies = fontDb.applicationFontFamilies(fontID)
        fontID = fontDb.addApplicationFont("simhei.ttf")  # 此处的路径为qrc文件中的字体路径
        fontFamilies = fontDb.applicationFontFamilies(fontID)
        # print(fontFamilies)  #
        # 设置窗口
        self.setWindowTitle("Yolov5-lite垃圾识别系统  作者:张瑞鹏")  # 窗口标题
        #self.resize(1024, 600)  # 窗口大小
        self.resize(800, 480)  # 窗口大小
        self.setFixedSize(self.width(), self.height())  # 设置窗口大小不可变
        #self.setCursor(Qt.BlankCursor)  # 隐藏鼠标
        self.imageLabel = QLabel(self)
        self.imageLabel.setGeometry(0, 0, 320, 240)
        self.imageLabel.setAlignment(Qt.AlignCenter)
        self.imageLabel.setScaledContents(True)
        self.imageLabel.setStyleSheet("QLabel{background:white;}")
        self.imageLabel.hide()
        # self.imageLabel.raise_()#最上层

        self.textShow = QLabel(self)
        self.textShow.setGeometry(320, 0, 100, 240)
        self.textShow.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.textShow.setScaledContents(True)
        self.textShow.setFont(QFont("simhei", 10))
        self.textShow.setStyleSheet("QLabel{background:white;}")
        self.textShow.hide()

        self.kindShow = QLabel(self)
        self.kindShow.setGeometry(320 + 100, 0, 80, 240)
        self.kindShow.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.kindShow.setScaledContents(True)
        self.kindShow.setFont(QFont("simhei", 10))
        self.kindShow.setStyleSheet("QLabel{background:white;}")
        self.kindShow.hide()

        self.numberShow = QLabel(self)
        self.numberShow.setGeometry(320, 0, 140+180, 170)
        self.numberShow.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.numberShow.setScaledContents(True)
        self.numberShow.setFont(QFont("simhei", 20))
        self.numberShow.setStyleSheet("QLabel{background:white;}")
        
        self.Tips2Show = QLabel(self)
        self.Tips2Show.setGeometry(320, 170, 140+180, 70)
        self.Tips2Show.setAlignment(Qt.AlignCenter)
        self.Tips2Show.setScaledContents(True)
        self.Tips2Show.setFont(QFont("simhei", 50))
        self.Tips2Show.setStyleSheet("QLabel{background:white;}")
        self.Tips2Show.setText("分类完成！")
        self.Tips2Show.hide()

        self.imageContent = QLabel(self)
        self.imageContent.setGeometry(640+10, 0, self.width() - (640+10), 240)
        self.imageContent.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.imageContent.setScaledContents(True)
        self.imageContent.setFont(QFont("simhei", 20))
        self.imageContent.setStyleSheet("QLabel{background:white;}")

        self.TipsShow = QLabel(self)
        self.TipsShow.setGeometry(0, 240, 1024, 600 - 240)
        self.TipsShow.setAlignment(Qt.AlignCenter)
        self.TipsShow.setScaledContents(True)
        self.TipsShow.setFont(QFont("KaiTi", 65))
        self.TipsShow.setStyleSheet("QLabel{background:white;}")
        self.TipsShow.setText("欢迎使用")
        
        self.WarningShow = QLabel(self)
        self.WarningShow.setGeometry(0, 0, self.width(), self.height())
        self.WarningShow.setAlignment(Qt.AlignCenter)
        self.WarningShow.setScaledContents(True)      # 保持自动缩放
        self.WarningShow.setFont(QFont("KaiTi", 60))  # 字号从100改为72
        self.WarningShow.setStyleSheet("QLabel{background:white;}")
        #self.WarningShow.setText("满载警报")
        self.WarningShow.hide()
        self.WarningShow.lower()
        
        
        # 在初始化代码中启动计时模块
        self.init_timer_module()
    
        self.wgt_video = QVideoWidget(self)  # 视频显示的widget
        self.player = QMediaPlayer(self)
        self.player.setVideoOutput(self.wgt_video)

        # 新增进度条控件
        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.setStyleSheet("""
            QSlider::groove:horizontal {
                background: #404040;
                height: 4px;
                border-radius: 2px;
            }
            QSlider::sub-page:horizontal {
                background: #00ff00;
                border-radius: 2px;
            }
            QSlider::add-page:horizontal {
                background: #606060;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                background: #ffffff;
                width: 12px;
                margin: -4px 0;
                border-radius: 6px;
            }
        """)
        self.slider.sliderMoved.connect(self.set_position)  # 拖拽进度
        self.slider.sliderPressed.connect(self.slider_pressed)
        self.slider.sliderReleased.connect(self.slider_released)

        # 布局设置（假设使用垂直布局）
        layout = QVBoxLayout()
        layout.addWidget(self.wgt_video)
        layout.addWidget(self.slider)
        self.setLayout(layout)

        self.player.setMedia(
            QMediaContent(QUrl.fromLocalFile("/home/yufeng/laji/mv0.mp4"))
        )

        # 连接信号
        self.player.durationChanged.connect(self.duration_changed)
        self.player.positionChanged.connect(self.position_changed)
        self.player.mediaStatusChanged.connect(self.handle_media_status_change)

        # 状态变量
        self.is_slider_pressed = False  # 标记是否正在拖拽


        # 其他原有设置保持不变...
        self.wgt_video.setGeometry(0, 0, self.width(), self.height())
        self.wgt_video.setStyleSheet("background:black;")
        self.player.play()

    def duration_changed(self, duration):
        """视频时长变化时更新进度条范围"""
        self.slider.setRange(0, duration)

    def position_changed(self, position):
        """更新进度条位置（非用户拖拽时）"""
        if not self.is_slider_pressed:
            self.slider.setValue(position)

    def set_position(self, position):
        """用户拖拽设置播放位置"""
        self.player.setPosition(position)

    def slider_pressed(self):
        """开始拖拽时暂停自动更新"""
        self.is_slider_pressed = True

    def slider_released(self):
        """结束拖拽时恢复自动更新"""
        self.is_slider_pressed = False

    def handle_media_status_change(self, status):
        """处理循环播放（原有功能）"""
        if status == QMediaPlayer.EndOfMedia:
            self.player.setPosition(0)
            self.player.play()


    def stop_video_playback(self):
        """完全停止并释放视频播放资源"""
        # 1. 停止播放
        self.player.stop()
        
        # 2. 释放媒体资源
        self.player.setMedia(QMediaContent())  # 传入空内容
        
        # 3. 隐藏视频控件（可选）
        self.wgt_video.hide()
        
        # 4. 如果需要可以释放播放器（谨慎使用）
        # self.player.deleteLater()
        # self.wgt_video.deleteLater()







    def play_video(self, video_path):
        """封装视频播放方法"""
        if self.player.state() == QMediaPlayer.PlayingState:
            self.player.stop()
        
        self.player.setMedia(
            QMediaContent(QUrl.fromLocalFile(video_path))
        )
        self.player.play()
        self.close_camera_window()
        print("开始播放视频...")



    # 在类中添加以下成员变量和方法
    def init_timer_module(self):
        # 计时变量
        self.tim = 0
        
        # 初始化定时器
        self.count_timer = QTimer(self)
        self.count_timer.timeout.connect(self.update_timer_count)
        self.count_timer.start(1000)  # 1秒触发一次




    def update_timer_count(self):
        """带条件判断的计时更新"""
        self.tim += 1
        print(f"[Timer] 当前计时: {self.tim}秒，状态: {self.timer_flag}")
        
        # 修改后的条件判断
        if self.tim > 10 and self.timer_flag == 1:
            if self.player.state() != QMediaPlayer.PlayingState:
                self.close_camera_window();
                self.play_video("/home/yufeng/laji/mv0.mp4")
                self.tim = 0  # 播放后自动重置计时
                self.timer_flag = 0  # 自动关闭触发

    def reset_timer(self):
        """重置计时器并启用flag"""
        print("[Timer] 重置并启用定时器")
        self.tim = 0
        self.timer_flag = 1  # 新增flag设置
   

    def disable_timer_flag(self):
        """主动禁用定时触发"""
        print("[Timer] 禁用定时触发")
        self.timer_flag = 0






    def gpioInit(self):
        pass

    def serialInit(self):
        if isRaspberryPi:
            self.serialBeginFlag = True
            self.serialEndFlag = False  # 接收完成标志
            self.ted = serial.Serial(port="/dev/ttyAMA0", baudrate=9600)
            #self.ted.write("Hello World!".encode("gbk"))
            self.serialDataTemp = ""
            self.serialData = ""



    def xysend(self, garbageKind, x, y):
        arr = bytes([ord('P'), x >> 8 & 0xFF, x & 0xFF, y >>
                    8 & 0xFF, y & 0xFF, garbageKind, ord('E')])
        self.ted.write(arr)

    def kindsend(self, garbageKind):
        arr = bytes([ord('K'), garbageKind, ord('E')])
        self.ted.write(arr)
        print(arr)






    def show_camera_window(self):
            """打开（显示）摄像头窗口控件"""
            self.imageLabel.show()
            self.imageLabel.raise_()     # 确保在最上层

    def close_camera_window(self):
        """关闭（隐藏）摄像头窗口控件"""
        self.imageLabel.hide()




    def show_warning(self, warning_type):
        """根据警告类型显示对应的满载警报"""
        self.current_warning_type = warning_type
        warning_messages = {
            "00": "可回收垃圾满载警报",
            "01": "厨余垃圾满载警报", 
            "02": "有害垃圾满载警报",
            "03": "其他垃圾满载警报"
        }
        target_text = warning_messages.get(warning_type, "满载警报")
        print(f"[DEBUG] 正在设置警报文本：{target_text}")  # 新增调试输出
        self.WarningShow.setText(target_text)        # 确保动画定时器存在
        if not hasattr(self, 'warning_animation'):
            self.warning_animation = QTimer(self)
            self.warning_animation.timeout.connect(self.toggle_warning_style)
        
        # 显示并启动动画
        self.WarningShow.show()
        self.WarningShow.raise_()
        self.warning_animation.start(500)

    def hide_warning(self):
        """隐藏警报并停止动画"""
        self.WarningShow.hide()
        if hasattr(self, 'warning_animation'):
            self.warning_animation.stop()





    def uartReceiveThread(self):
        """串口数据接收线程（带视频控制功能和状态切换）"""
        if isRaspberryPi:
            while True:
                if self.ted.inWaiting() > 0:
                    try:
                        # 读取并清理串口数据
                        raw_data = self.ted.readline()
                        self.serialData = raw_data.decode("gbk", errors='ignore').strip()
                        self.serialEndFlag = True
                        print(f"[Serial] 原始接收数据: {repr(self.serialData)}")  # 显示转义字符

                        try:
                            # 修改SR1命令处理部分
                            if "SR1=" in self.serialData:
                                # 增强型参数提取
                                cmd_part = self.serialData.partition("SR1=")[2]
                                cmd_value = cmd_part[:2].strip()  # 清理空白字符
                                print(f"[DEBUG] 提取参数：SR1={cmd_value}")  # 新增调试输出
                                
                                if cmd_value in ["00", "01", "02", "03"]:
                                    self.warning_mode = True
                                    self.show_warning(cmd_value)
                                    self.reset_timer()
                                    print(f"[System] 进入{cmd_value}类型警报状态")
                                    
                                elif cmd_value == "ZZ":
                                    self.warning_mode = False
                                    self.hide_warning()
                                    print("[System] 恢复正常状态")
                                
                                continue                                
                            # 如果处于警报状态，不处理其他命令
                            if getattr(self, 'warning_mode', False):
                                continue

                            # TPS命令：停止视频并拍照
                            if "TPS" in self.serialData:
                                self.disable_timer_flag()
                                self.show_camera_window()
                                self.stop_video_playback()
                                self.takePhotoFlag = 1
                                
                            # TPYL命令：开始垃圾识别流程
                            elif "TPYL" in self.serialData:
                                self.personDistence[0] = 10
                                print("[System] 垃圾检测 - 开始识别流程")
                                self.check_have_garbage_flag = 1
                                self.check_have_garbage_flag_ok = 0
                                time.sleep(2)
                                self.flag = 1
                                self.isshibie = 0
                                self.timer_common_flag_temp = 1
                                
                            # TPYOK命令：完成分类处理
                            elif "TPYOK" in self.serialData:
                                print("[System] 垃圾分类完成")
                                
                                # 更新计数
                                self.number += 1
                                self.kind_number[self.topic1_kind] += self.photo_kind_number
                                
                                # 发送实际识别到的垃圾类型
                                #if 0 <= self.topic1_kind <= 255:
                                    #self.send_text_data(
                                        #garbageKind=self.topic1_kind,
                                        #x=1,  # 实际坐标根据需求修改
                                        #y=1
                                    #)
                                 #   self.kindsend(self.topic1_kind)
                                #else:
                                 #   print(f"[Error] 无效的垃圾类型编号：{self.topic1_kind}")

                                # 更新UI显示
                                status_text = "{:2d} {:s}{:2d} OK!".format(
                                    self.number,
                                    self.garbagekind[self.topic1_kind],
                                    self.kind_number[self.topic1_kind]
                                )
                                self.update_status_display(status_text)
                                
                                # 重置标志
                                self.check_have_garbage_flag_ok = 1
                                self.flag = 0
                                self.timer_common_flag_temp = 0
                                self.photo_kind_number = 0
                                self.reset_timer()
                                
                        except Exception as e:
                            print(f"[Error] 数据处理异常: {str(e)}")
                            
                    except Exception as e:
                        print(f"[Error] 串口读取异常: {str(e)}")
                else:
                    time.sleep(0.1)






    def stop_video_playback(self):
        """安全停止视频播放"""
        if self.player.state() != QMediaPlayer.StoppedState:
            self.player.stop()
            self.player.setMedia(QMediaContent())  # 清空媒体内容
        self.wgt_video.hide()

    def play_video(self, video_path):
        """带错误处理的视频播放"""
        if os.path.exists(video_path):
            try:
                self.player.setMedia(QMediaContent(QUrl.fromLocalFile(video_path)))
                self.wgt_video.show()
                self.player.play()
                print(f"[Video] 正在播放: {video_path}")
            except Exception as e:
                print(f"[Error] 视频播放失败: {str(e)}")
        else:
            print(f"[Error] 视频文件不存在: {video_path}")

    def update_status_display(self, status_text):
        """更新状态显示（UI线程安全）"""
        # 主界面显示
        self.numberShow.setText(
            "序号  垃圾种类  累计数量\r\n" +
            f" 1    有害垃圾    {self.kind_number[2]:d}\r\n" +
            f" 2    可回收垃圾  {self.kind_number[0]:d}\r\n" +
            f" 3    厨余垃圾    {self.kind_number[1]:d}\r\n" +
            f" 4    其它垃圾    {self.kind_number[3]:d}\r\n"
        )
        self.TipsShow.setText(status_text)
        
        # 完成提示（超过10次时显示）
        if self.number >= 10:
            self.Tips2Show.show()
            
            
            


    def classifyGarbage(self, id):
        for i in range(0, 4, 1):
            kind = self.garbagekindlist[i]
            # print(kind)
            try:
                if kind.index(id) != -1:
                    return i
            except:
                pass
        return -1

    def loadModel(self):
        # 模型加载
        model_pb_path = "best.onnx"
        self.so = ort.SessionOptions()
        self.net = ort.InferenceSession(
            model_pb_path, providers=[
                "AzureExecutionProvider", "CPUExecutionProvider"]
        )

        # 模型参数
        self.model_h = 320
        self.model_w = 320
        self.nl = 3
        self.na = 3
        self.stride = [8.0, 16.0, 32.0]
        self.anchors = [
            [10, 13, 16, 30, 33, 23],
            [30, 61, 62, 45, 59, 119],
            [116, 90, 156, 198, 373, 326],
        ]
        self.anchor_grid = np.asarray(self.anchors, dtype=np.float32).reshape(
            self.nl, -1, 2
        )

    def timer_commonout(self):
        if self.timer_common_flag == 1 and self.isshibie != 1 and self.flag == 1:
            self.topic1_kind = 3
            self.kindsend(self.topic1_kind)
            print("未识别到--砖块 其它垃圾")
            self.pictextShow = (
                "{:2d}.{:s}".format(
                    self.number+1, self.dic_labels_cn[9]) + "\n" + self.pictextShow
            )
            self.kindText = (
                "{:s}".format(self.garbagekind[int(
                    self.classifyGarbage(9))]) + "\n" + self.kindText
            )
            self.textShow.setText(self.pictextShow)
            self.kindShow.setText(self.kindText)
            self.flag = 0
            self.isshibie = 1
            self.timer_common_flag = 0
            self.timer_common_flag_temp = 0
            self.timer_common.start(10)
        if self.timer_common_flag_temp == 1 and self.flag == 1:
            self.timer_common_flag = 1
            self.timer_common.start(1000)

    def stateRefresh(self):
        if isRaspberryPi:
            root.showFullScreen()
        def checkDistance():
            for i in self.personDistence:
                if isRaspberryPi == False:
                    return 1
                if i < 30:
                    return 1
            return 0

        if checkDistance():
            self.personFlag = 1
        else:
            self.personFlag = 1
            self.personFlag = 0
        if (
            self.personFlag == 0
        ):
        # if (
        #     self.player.state() != QMediaPlayer.State.PlayingState
        #     and self.personFlag == 0
        # ):
            self.timer.stop()
            # self.wgt_video.setGeometry(0, 0, self.width(), self.height())
            # self.wgt_video.show()
            # self.wgt_video.raise_()
            # self.player.play()
        if (
            self.personFlag == 1
        ):
        # if (
        #     self.player.state() == QMediaPlayer.State.PlayingState
        #     and self.personFlag == 1
        # ):
            self.timer.start(10)
            # self.wgt_video.hide()
            # self.wgt_video.lower()
            # self.player.pause()

    def showImage(self):
        i_flag = 0
        global pre_cnt, new_num
        if self.busy == 0:
           self.busy = 1
           self.picContent = []
        
        # 使用picamera2获取图像
           self.img = self.picam2.capture_array()  # 获取图像数据

           if self.flag:
            # 进行垃圾分类推理
              det_boxes, scores, ids = infer_img(
                  self.img,
                  self.net,
                  self.model_h,
                  self.model_w,
                  self.nl,
                  self.na,
                  self.stride,
                  self.anchor_grid,
                  thred_nms=0.4,
                  thred_cond=0.5,
              )
              i = 0
              i_flag = 0
              for box, score, id in zip(det_boxes, scores, ids):
                  label = "%s:%.2f" % (self.dic_labels[id], score) #1                 
                  self.picContent.append(self.imageContentResult())
                  self.picContent[i].id = id
                  self.picContent[i].postion[0] = (box[2] + box[0]) / 2    #1
                  self.picContent[i].postion[1] = (box[3] + box[1]) / 2    #1
                  i = i + 1
                  i_flag = i
                  plot_one_box(
                      box.astype(np.int32),
                      self.img,
                     color=(255, 0, 100),
                      label=label,
                     line_thickness=None,
                 )

                  
                  
           picContentText = ""
           if self.picContent != None:
              if i_flag != 0:
                  self.photo_kind_number = 0
                  if len(self.picContent) > 0:
                      j = self.picContent[0]
                      self.photo_kind_number = 1
                      self.topic1_id = j.id
                      self.topic1_kind = int(self.classifyGarbage(j.id))
                  if self.topic1_kind == -1:
                      self.topic1_kind = 9
                  if self.isshibie == 0:
                      self.kindsend(self.topic1_kind)
                      self.isshibie = 1
                  self.pictextShow = (
                      "{:2d}.{:s}".format(self.number+1, self.dic_labels_cn[j.id])+ "\n"+ self.pictextShow
                  )
                  self.kindText = (
                    "{:s}".format(self.garbagekind[int(self.classifyGarbage(j.id))])+ "\n"+ self.kindText
                  )
                  self.textShow.setText(self.pictextShow)
                  self.kindShow.setText(self.kindText)
                  print(self.dic_labels_cn[j.id],
                        self.garbagekind[self.topic1_kind],
                        self.photo_kind_number)
                  print(f"正确率:{j.score*2:.2f}%")
                  self.flag = 0
                  self.timer_common_flag_temp = 0
                  self.timer_common_flag_temp = 0
              img = self.cvimg2qtimg(self.img)  # OpenCV图像转换为Qt图像格式
              self.imageLabel.setPixmap(img)
              if self.takePhotoFlag == 1:
                # 生成文件名
                  filename = folder_path + "/image_{}.png".format(new_num)
                # 按新的文件名保存照片到SD卡
                  img.save(filename, format="PNG", quality=100)
                  print("/image_{}.png saved finished!".format(new_num))
                  #self.TipsShow.setText("image_{}.png 保存 OK!".format(new_num))
                # 记录当前照片数
                  new_num = new_num + 1
                  time.sleep(0.5)
                  self.takePhotoFlag = 0

              self.busy = 0
    def cvimg2qtimg(self, cvimg):
        height, width, depth = cvimg.shape
        cvimg = cv2.cvtColor(cvimg, cv2.COLOR_BGR2RGB)
        cvimg = QImage(
            cvimg.data.tobytes(), width, height, width * depth, QImage.Format_RGB888
        )
        # print(type(cvimg))
        return QPixmap.fromImage(cvimg)


# 主程序
if __name__ == "__main__":
    application = QApplication(sys.argv)  # 窗口通讯
    root = Main()  # 创建对象
    
    root.show()  # 展示窗口
    if isRaspberryPi:
        root.showFullScreen()
    sys.exit(application.exec_())  # 消息循环
